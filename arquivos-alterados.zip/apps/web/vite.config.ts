import { copyFileSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { defineConfig, loadEnv, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

/**
 * Preenche %API_ORIGIN% do public/_headers (CSP connect-src) com a origem de VITE_API_URL,
 * para o Cloudflare Pages liberar as chamadas à API sem edição manual.
 */
function apiOriginInHeaders(apiUrl: string): Plugin {
  return {
    name: 'api-origin-in-headers',
    apply: 'build',
    closeBundle() {
      const file = resolve(__dirname, 'dist', '_headers');
      let origin = '';
      if (apiUrl !== 'same-origin') {
        try {
          origin = new URL(apiUrl).origin;
        } catch {
          throw new Error(`VITE_API_URL inválida: "${apiUrl}" (use https://... ou same-origin)`);
        }
      }
      writeFileSync(file, readFileSync(file, 'utf8').replaceAll(' %API_ORIGIN%', origin ? ` ${origin}` : ''));
    },
  };
}

/**
 * GitHub Pages não envia cabeçalhos próprios nem tem regras de rota:
 * a política de segurança vai como <meta> e o 404.html devolve o próprio site,
 * para que links diretos (ex.: /registros) funcionem.
 */
function githubPages(apiUrl: string): Plugin {
  let origin = '';
  if (apiUrl !== 'same-origin') origin = new URL(apiUrl).origin;
  const csp =
    "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; " +
    `font-src 'self' data:; connect-src 'self'${origin ? ` ${origin}` : ''}; base-uri 'self'; form-action 'self'; object-src 'none'`;
  return {
    name: 'github-pages',
    apply: 'build',
    transformIndexHtml(html) {
      return html.replace(
        '<meta charset="UTF-8" />',
        `<meta charset="UTF-8" />\n    <meta http-equiv="Content-Security-Policy" content="${csp}" />\n    <meta name="referrer" content="strict-origin-when-cross-origin" />`,
      );
    },
    closeBundle() {
      const dist = resolve(__dirname, 'dist');
      copyFileSync(resolve(dist, 'index.html'), resolve(dist, '404.html'));
      for (const f of ['_headers', '_redirects']) rmSync(resolve(dist, f), { force: true });
    },
  };
}

export default defineConfig(({ mode }) => {
  const env = { ...loadEnv(mode, __dirname, 'VITE_'), ...process.env };
  const apiUrl = env.VITE_API_URL || 'http://localhost:3333';
  return {
    // VITE_BASE: subpasta de publicação (GitHub Pages: /gestao-registros-xml/)
    base: env.VITE_BASE || '/',
    plugins: [
      react(),
      tailwindcss(),
      // Cloudflare Pages usa o _headers; GitHub Pages recebe a política no próprio HTML
      env.VITE_DEPLOY_TARGET === 'github-pages' ? githubPages(apiUrl) : apiOriginInHeaders(apiUrl),
    ],
    // o pacote compartilhado do monorepo é consumido direto do código-fonte TS
    optimizeDeps: { exclude: ['@gestao/shared'] },
    server: { port: 5173 },
    build: { outDir: 'dist', sourcemap: false, chunkSizeWarningLimit: 1200 },
  };
});
