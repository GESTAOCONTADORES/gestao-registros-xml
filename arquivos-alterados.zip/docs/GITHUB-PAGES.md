# Site do sistema no GitHub Pages

O site (login, dashboard, registros, empresas, usuários…) pode ser publicado no
**GitHub Pages**, no lugar do Cloudflare Pages. O workflow
`.github/workflows/pages.yml` gera e publica o site sozinho a cada envio ao
branch `main`.

| Endereço | Conteúdo |
|---|---|
| `https://gestaocontadores.github.io/gestao-registros-xml/` | Site do sistema |
| `https://gestaocontadores.github.io/gestao-registros-xml/sobre/` | Página de apresentação do robô (`docs/index.html`) |

> O GitHub Pages hospeda **só o site**. O servidor (API e banco) e o robô continuam
> no escritório (`GestaoXmlServidor-Setup.exe`), e a API precisa estar acessível
> por HTTPS pela internet, o que é feito pelo Cloudflare Tunnel
> ([SERVIDOR-WINDOWS.md](SERVIDOR-WINDOWS.md), passos 1 e 2).

## Antes de começar
- **Repositório privado:** o GitHub Pages em repositório privado exige plano pago
  da organização (GitHub Team ou Enterprise). Em *Settings › Pages* aparece um
  aviso se o plano não permitir.
- **O site publicado é público** (exceto no GitHub Enterprise Cloud com
  visibilidade privada). Isso é aceitável: o site só tem a tela de login e a
  interface. Nenhum XML, dado ou segredo fica nele. Tudo vem da API, que exige
  login aprovado.

## Passo 1 — Ativar o GitHub Pages
1. No repositório, abra **Settings › Pages**.
2. Em **Build and deployment › Source**, escolha **GitHub Actions**.

## Passo 2 — Informar o endereço da API
1. Abra **Settings › Secrets and variables › Actions** e entre na aba **Variables**.
2. Clique em **New repository variable**:
   - **Name:** `VITE_API_URL`
   - **Value:** `https://api-registros.gestaocontadores.com.br` (o endereço público do
     túnel, sem barra no final)
3. Clique em **Add variable**.

## Passo 3 — Publicar
1. Abra **Actions › Site (GitHub Pages)** e clique em **Run workflow › Run workflow**.
   Depois disso, o site é republicado sozinho a cada envio ao `main`.
2. Em cerca de 2 minutos o endereço aparece no resultado do workflow e em
   *Settings › Pages*.

## Passo 4 — Autorizar o site no servidor
O servidor só aceita chamadas de sites autorizados. No computador do servidor:
1. Abra **Menu Iniciar › Gestão XML Servidor › Editar configuração**.
2. Em `CORS_ORIGINS`, coloque `https://gestaocontadores.github.io` (só o domínio,
   **sem** `/gestao-registros-xml`). Vários endereços vão separados por vírgula.
3. Confira `COOKIE_SECURE=true` e `COOKIE_SAMESITE=none` (padrão do instalador).
4. Salve e responda **S** para reiniciar.

Ao reinstalar o servidor, basta informar o mesmo endereço no campo
**Endereço do site**.

## Domínio próprio (opcional)
Para usar, por exemplo, `https://registros.gestaocontadores.com.br`:
1. Em **Settings › Pages › Custom domain**, informe o domínio e salve.
2. No DNS do domínio, crie um registro `CNAME` de `registros` para
   `gestaocontadores.github.io`.
3. Crie a variável `VITE_BASE` com o valor `/` (o site deixa de ficar na
   subpasta) e rode o workflow de novo.
4. No servidor, troque `CORS_ORIGINS` para `https://registros.gestaocontadores.com.br`.

## Problemas comuns
| Sintoma | Solução |
|---|---|
| Workflow falha em "Conferir o endereço da API" | A variável `VITE_API_URL` não foi criada (Passo 2). |
| Workflow fica parado na fila | O GitHub Actions não está liberado na organização (*Settings › Actions › General*) ou acabaram os minutos do plano. |
| Site abre, mas o login dá erro de rede | API fora do ar ou túnel parado: abra `https://api-registros.../health`. Se responder, o endereço do site não está em `CORS_ORIGINS` (Passo 4). |
| Página em branco | O site foi publicado com a subpasta errada: confira a variável `VITE_BASE` (só use `/` com domínio próprio). |
